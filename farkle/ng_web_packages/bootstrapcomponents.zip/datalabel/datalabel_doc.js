/* DataLabel is a label component that can show dynamic text and (optionally) an image. */

