
$scope.api.showLightbox = function() {
}

$scope.api.refresh = function() {
}
